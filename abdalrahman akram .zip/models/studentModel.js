const mongoose = require('mongoose');

const studentSchema = new mongoose.Schema({
  name: { type: String, required: true },
  age: Number,
  department: String
}, { timestamps: true });

// Add text index on name for search
studentSchema.index({ name: 'text' });

module.exports = mongoose.model('Student', studentSchema);
