const express = require('express');
const router = express.Router();
const ctrl = require('../controllers/studentController');

function isAuth(req, res, next) {
  if (!req.session.user) return res.redirect('/login');
  next();
}

router.get('/', isAuth, ctrl.listStudents);
router.get('/add', isAuth, ctrl.showAdd);
router.post('/add', isAuth, ctrl.createStudent);
router.get('/edit/:id', isAuth, ctrl.showEdit);
router.post('/edit/:id', isAuth, ctrl.updateStudent);
router.get('/delete/:id', isAuth, ctrl.deleteStudent);

module.exports = router;
