const express = require('express');
const router = express.Router();
const auth = require('../controllers/authController');

router.get('/register', auth.registerForm);
router.post('/register', auth.registerUser);

router.get('/login', auth.loginForm);
router.post('/login', auth.loginUser);

router.get('/logout', auth.logout);

module.exports = router;
