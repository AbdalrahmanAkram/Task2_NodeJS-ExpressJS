const bcrypt = require('bcrypt');
const User = require('../models/userModel');

exports.registerForm = (req, res) => {
  res.render('register');
};

exports.registerUser = async (req, res) => {
  try {
    const { email, password } = req.body;
    const existing = await User.findOne({ email }).exec();
    if (existing) return res.send('User already exists');
    const hash = await bcrypt.hash(password, 10);
    await User.create({ email, password: hash });
    res.redirect('/login');
  } catch (err) {
    console.error(err);
    res.status(500).send('Error registering user');
  }
};

exports.loginForm = (req, res) => {
  res.render('login');
};

exports.loginUser = async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email }).exec();
    if (!user) return res.send('Invalid email or password');
    const ok = await bcrypt.compare(password, user.password);
    if (!ok) return res.send('Invalid email or password');
    req.session.user = { id: user._id, email: user.email };
    res.redirect('/students');
  } catch (err) {
    console.error(err);
    res.status(500).send('Error logging in');
  }
};

exports.logout = (req, res) => {
  req.session.destroy(err => {
    res.redirect('/login');
  });
};
