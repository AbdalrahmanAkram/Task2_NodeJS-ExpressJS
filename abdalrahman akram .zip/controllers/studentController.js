const Student = require('../models/studentModel');

exports.listStudents = async (req, res) => {
  const q = req.query.q || '';
  try {
    let students;
    if (q) {
      students = await Student.find({ $text: { $search: q } }).exec();
    } else {
      students = await Student.find().sort({ createdAt: -1 }).exec();
    }
    res.render('students/list', { students, q });
  } catch (err) {
    console.error(err);
    res.status(500).send('Server error');
  }
};

exports.showAdd = (req, res) => {
  res.render('students/add');
};

exports.createStudent = async (req, res) => {
  try {
    await Student.create(req.body);
    res.redirect('/students');
  } catch (err) {
    console.error(err);
    res.status(400).send('Bad request');
  }
};

exports.showEdit = async (req, res) => {
  try {
    const student = await Student.findById(req.params.id).exec();
    if (!student) return res.redirect('/students');
    res.render('students/edit', { student });
  } catch (err) {
    console.error(err);
    res.redirect('/students');
  }
};

exports.updateStudent = async (req, res) => {
  try {
    await Student.findByIdAndUpdate(req.params.id, req.body).exec();
    res.redirect('/students');
  } catch (err) {
    console.error(err);
    res.redirect('/students');
  }
};

exports.deleteStudent = async (req, res) => {
  try {
    await Student.findByIdAndDelete(req.params.id).exec();
    res.redirect('/students');
  } catch (err) {
    console.error(err);
    res.redirect('/students');
  }
};
